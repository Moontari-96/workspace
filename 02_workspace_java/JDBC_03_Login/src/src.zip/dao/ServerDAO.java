package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import dto.ServerDTO;


public class ServerDAO {
	private String dbURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String dbID = "kedu";
	private String dbPW = "kedu";
	private Connection getConnection() throws Exception {
		return DriverManager.getConnection(dbURL, dbID, dbPW);
	}
	
	public int addMembers(ServerDTO dto) throws Exception {
		String sql = "insert into members values('" + dto.getId() + "', '"+dto.getPw()+ "', '" + dto.getName() + "')";
		try(
			Connection con = this.getConnection();
			Statement stat = con.createStatement();
				){
			int result = stat.executeUpdate(sql);
			return result;
		}
	}
	
	public boolean validMembers(ServerDTO dto) throws Exception {
		String sql = "select * from members where id = '" + dto.getId() + "' and pw = '" + dto.getPw() + "'";
		System.out.println(sql);
		try(
			Connection con = this.getConnection();
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery(sql);
				) {
			boolean result = rs.next();
			return result;
		}
		
	}	
}
