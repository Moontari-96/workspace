$(function () {
  var page = $('#fullpage').fullpage({
    // 스크롤 허용 옵션 표기
    navigation: true, // 섹션 탐색 메뉴 표시
    verticalCentered: true,
    scrollHorizontally: true,
  });
});
